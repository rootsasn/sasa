#pragma once

#define HTTP_SERVER "160.191.245.40"
#define HTTP_PORT 80

#define TFTP_SERVER "160.191.245.40"
